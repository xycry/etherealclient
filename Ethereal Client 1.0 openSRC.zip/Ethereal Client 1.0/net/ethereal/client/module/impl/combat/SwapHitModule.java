package net.ethereal.client.module.impl.combat;

import net.ethereal.client.module.ClientModule;
import net.ethereal.client.module.ModuleCategory;
import net.ethereal.client.module.setting.BooleanSetting;
import net.ethereal.client.module.setting.NumberSetting;

/**
 * Swap Hit – automatically switches to a sword when attacking.
 */
public final class SwapHitModule extends ClientModule {
    private final BooleanSetting enabled = this.addSetting("enabled", new BooleanSetting("Enabled", true));
    private final NumberSetting swapDelay = this.addSetting("swap-delay", new NumberSetting("Swap Delay (ms)", 0.0, 0.0, 200.0).step(10.0));

    public SwapHitModule() {
        super("swap-hit", "Swap Hit", "Auto‑switches to a sword when hitting an entity.", ModuleCategory.COMBAT);
    }
}
