package net.ethereal.client.module.impl.combat;

import net.ethereal.client.module.ClientModule;
import net.ethereal.client.module.ModuleCategory;
import net.ethereal.client.module.setting.BooleanSetting;
import net.ethereal.client.module.setting.NumberSetting;

/**
 * Safe Anchor – protects the player from being pushed or knocked back while anchoring.
 * Stub implementation; real logic would monitor anchor state and apply position locks.
 */
public final class SafeAnchorModule extends ClientModule {
    private final BooleanSetting enabled = this.addSetting("enabled", new BooleanSetting("Enabled", true));
    private final NumberSetting anchorRadius = this.addSetting("anchor-radius", new NumberSetting("Anchor Radius", 2.0, 0.5, 5.0).step(0.1));

    public SafeAnchorModule() {
        super("safe-anchor", "Safe Anchor", "Prevents knockback while anchoring.", ModuleCategory.COMBAT);
    }
}
