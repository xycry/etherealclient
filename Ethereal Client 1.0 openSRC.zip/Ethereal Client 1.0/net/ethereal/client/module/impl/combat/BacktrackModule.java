package net.ethereal.client.module.impl.combat;

import net.ethereal.client.module.ClientModule;
import net.ethereal.client.module.ModuleCategory;
import net.ethereal.client.module.setting.BooleanSetting;
import net.ethereal.client.module.setting.NumberSetting;

/**
 * Backtrack – delays incoming packets to make targets easier to hit.
 * Stub implementation; actual packet handling would be added via mixins.
 */
public final class BacktrackModule extends ClientModule {
    private final NumberSetting delayMs = this.addSetting("delay-ms", new NumberSetting("Delay (ms)", 50.0, 0.0, 200.0).step(5.0));
    private final BooleanSetting enabled = this.addSetting("enabled", new BooleanSetting("Enabled", true));

    public BacktrackModule() {
        super("backtrack", "Backtrack", "Delays incoming packets to make targets easier to hit.", ModuleCategory.COMBAT);
    }
}
