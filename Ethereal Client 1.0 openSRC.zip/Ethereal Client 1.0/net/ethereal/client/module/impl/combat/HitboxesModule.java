package net.ethereal.client.module.impl.combat;

import net.ethereal.client.module.ClientModule;
import net.ethereal.client.module.ModuleCategory;
import net.ethereal.client.module.setting.BooleanSetting;
import net.ethereal.client.module.setting.NumberSetting;

/**
 * Hitboxes – expands the player's hitbox size for easier hits.
 * Stub implementation; actual hitbox scaling would be performed via mixins.
 */
public final class HitboxesModule extends ClientModule {
    private final NumberSetting scale = this.addSetting("scale", new NumberSetting("Hitbox Scale", 1.5, 1.0, 3.0).step(0.1));
    private final BooleanSetting enabled = this.addSetting("enabled", new BooleanSetting("Enabled", true));

    public HitboxesModule() {
        super("hitboxes", "Hitboxes", "Expands player hitboxes to make hits easier.", ModuleCategory.COMBAT);
    }
}
