package net.ethereal.client.module.impl.combat;

import net.ethereal.client.module.ClientModule;
import net.ethereal.client.module.ModuleCategory;
import net.ethereal.client.module.setting.BooleanSetting;
import net.ethereal.client.module.setting.NumberSetting;

/**
 * Hit Effect – renders particle effects when an entity is hit.
 * Stub implementation; real effect would be rendered in the attack event handler.
 */
public final class HitEffectModule extends ClientModule {
    private final BooleanSetting enabled = this.addSetting("enabled", new BooleanSetting("Enabled", true));
    private final NumberSetting particleCount = this.addSetting("particle-count", new NumberSetting("Particle Count", 10.0, 1.0, 50.0).step(1.0));

    public HitEffectModule() {
        super("hit-effect", "Hit Effect", "Shows particle effects on hit.", ModuleCategory.COMBAT);
    }
}
